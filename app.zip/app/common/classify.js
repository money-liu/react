import React, { Component } from 'react';
import {Text, StyleSheet, Image, View, ListView, Alert, TouchableHighlight, InteractionManager, TouchableOpacity, Platform, AsyncStorage } from 'react-native';
import ViewPager from 'react-native-viewpager';
import RecipeDetail from '../pages/RecipeDetail1';

var THUMB_URLS = [
  require('../static/images/like.png'),
  require('../static/images/dislike.png'),
  require('../static/images/call.png'),
  require('../static/images/fist.png'),
  require('../static/images/flowers.png'),
  require('../static/images/heart.png'),
  require('../static/images/liking.png'),
  require('../static/images/party.png'),
];

class Classify extends Component {
  constructor(props) {
      super(props);
      // 用于构建DataSource对象
      var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
      // 实际的DataSources存放在state中
      this.state = {
          // selectedTab: tabBarItems[0].title,
          selectedTab: 'blueTab',
          notifCount: 0,
          presses: 0,
          dataSource2:ds.cloneWithRows(this._genRows({})),
      };
  }

  _renderPage(data, pageID) {
     return (
         <Image source={data} style={styles.page}/>
     );
 }

  render() {
    return (
        <View>
          <TouchableOpacity onPress={this.rightAction}>
            <View style={styles.ClassMenu}>
              <View style={styles.ClassifyBlock}>
                  <Image source={require('../static/images/icon-auction.png')} style={styles.ClassifyImg} />
                  <Text style={styles.ClassifyText}>极鲜拍</Text>
               </View>
               <View style={styles.ClassifyBlock} >
                   <Image source={require('../static/images/icon-purchase.png')} style={styles.ClassifyImg}/>
                   <Text style={styles.ClassifyText}>我要购买</Text>
               </View>
               <View style={styles.ClassifyBlock} >
                   <Image source={require('../static/images/icon-regular.png')} style={styles.ClassifyImg}/>
                   <Text style={styles.ClassifyText}>定期购</Text>
               </View>
               <View style={styles.ClassifyBlock} >
                   <Image source={require('../static/images/icon-vip.png')} style={styles.ClassifyImg}/>
                   <Text style={styles.ClassifyText}>精英会员</Text>
               </View>
               <View style={styles.ClassifyBlock} >
                 <Image source={require('../static/images/icon-logistics.png')} style={styles.ClassifyImg}/>
                 <Text style={styles.ClassifyText}>物流/发票</Text>
               </View>
            </View>
          </TouchableOpacity>
            <ListView
               initialListSize={13*2}
               contentContainerStyle={styles.list}
               dataSource={this.state.dataSource2}
               renderRow={this._renderRow}
             />
        </View>
    )
  }

  // ssss() {
  //   fetch('http://www.pintasty.cn/home/homedynamic', {
  //     method: 'post',
  //     headers: {  //header
  //        'token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJVLTliZGJhNjBjMjZiMDQwZGJiMTMwYWRhYWVlN2FkYTg2IiwiZXhwaXJhdGlvblRpbWUiOjE0NzUxMTg4ODU4NTd9.ImbjXRFYDNYFPtK2_Q2jffb2rc5DhTZSZopHG_DAuNU'
  //     },
  //     body: JSON.stringify({    //参数
  //       'start': '0',
  //       'limit': '20',
  //       'isNeedCategory': true,
  //       'lastRefreshTime': '2016-09-25 09:45:12'
  //     })
  //   })
  //   .then((response) => response.json())  //把response转为json
  //   .then((responseDate) => {
  //     alert(responseDate);
  //   })
  //   .catch((error)=> {
  //       alert('错误了');
  //   })
  // }

  /*
  *  get请求
  *  url:请求地址
  *  data:参数
  *  callback:回调函数
  * */
//   static post(url,params,callback){
//
//    //fetch请求
//    fetch(url,{
//        method: 'POST',
//        body:JSON.stringify(params)
//    })
//    .then(
//      (response) => response.text()
//    )
//    .then((responseJSON) =>{
//       callback()
//
//    }) .done();
//    }
//
//
//
//  rightAction(){
//     var host = 'http://10.10.20.40:8080/no/client';
//     let headers = {'Accept': 'application/json','Content-Type': 'application/x-www-form-urlencoded'};
//     let params = {'disclass':'product','action':'gfreshHome','PortID':'1'};
//
//     Classify.post(host,params,function (set) {
//         console.dir(params)
//     })
//
// }





  _renderRow(rowData,sectionID,rowID)
    {
      var imgSource = THUMB_URLS[rowID];
      return (
        <View style={styles.row}>
          <Image style={styles.thumb} source={imgSource} />
          <Text style={styles.text}>
            {rowData}
          </Text>
        </View>
      );
    }

  _genRows(pressData: {[key: number]:boolean}): Array<string>
    {
      var dataBlob = [];
      for (var ii = 0; ii < THUMB_URLS.length;ii++) {
        dataBlob.push('单元格 ' + ii);
      }
      console.log('第'+ii+'个');
      return dataBlob;
    }

}


const styles = StyleSheet.create({
  page: {
     flex: 1,
     resizeMode: 'stretch'
  },
  list: {
    justifyContent: 'center',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',//'center'
    padding: 5,
    margin:6,
    width: 85,
    height: 85,
    alignItems: 'center',
  },
  thumb: {
    width: 45,
    height: 45
  },
  text: {
    flex: 1,
    marginTop: 5,
    fontSize:12,
  },
ClassMenu: {
  justifyContent: 'center',
  flexDirection: 'row',
  flexWrap: 'wrap',
  height: 80,
  marginLeft:20,
  marginTop:10,
  marginBottom: 10,
  alignItems: 'center',
},
ClassifyImg: {
  width:50,
  height:50,
},
ClassifyBlock: {
  width:75,
  height:80,
  flex:1,
},
ClassifyText: {
  fontSize: 12,
}
})

module.exports = Classify;
